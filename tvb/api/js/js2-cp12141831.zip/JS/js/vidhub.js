muban.mxone5.二级.desc = ';;.video-info-items:eq(2);.video-info-items:eq(1);.video-info-items:eq(0)';
var rule = Object.assign(muban.mxone5,{
    title:'Vid影视',
    host:'https://vidhub.cc',
    url:'/vodshow/fyclass--------fypage---.html',
    searchUrl:'/vodsearch/**----------fypage---.html',
    cate_exclude:'网址+',
    tab_exclude:'主选一',
});










